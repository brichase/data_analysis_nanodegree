# Udacity DAND Project: Prosper Loan Rating Scores Visualization

## Summary
This visualization shows how Prosper's rating system of individual loans
changed from being almost solely based on the individual's credit rating to
having much less correlation after July of 2009---when they moved from
CreditGrade to ProsperRating.

As background, Prosper is a peer-to-peer lending platform that allows people
to invest directly into personal loans.

Loans are rated from AA (best -- most credit worthy) to HR (worst -- least
credit worthy).

## Design
#### Initial design:  
My first thought is to convey the information that CreditGrade was highly
correlated with CreditScore and ProsperRating is correlated not as much with CreditScore than BorrowerAPR.

To show this, my plan was two scatter plots---side by side---showing both CreditScore and BorrowerAPR colored by CreditScore and the other ProsperRating.

The color scheme used highlights the sequential ordered nature of the ratings.
B is a better rating than A and so on.

There was a bug in dimplejs where some datapoints would cause the chart to not
appear. So I cleaned the first 200 datapoints and used that.

#### Iterations:
The viewers had issues picking out my main findings in the charts. So I pivoted
to using histograms and only kept CreditScore bins as categories to highlight this effect.

Using histograms allowed me to use the full data. (Quite large--could do some extra processing to make it load quickly)

Another reason that I removed the BorrowerAPR data from the charts is when it
occurred to me that ProsperScore was the main determinant of the APR
(one of the main reasons!).

I also changed the accompanying text/titles to highlight the change of credit score---before and after.

## Feedback
Reviewer #1 (initial iteration):
* What is APR?
* The key is backwards and not completely ordered
* Not sure what she was supposed to be looking for---but she saw the pattern after a few moments. Also some other patterns.

Reviewer #2: (initial iteration)
* Titles are confusing
* What am I supposed to be looking for?

Reviewer #3: (One iteration before final)  
* What is CreditGradeCat?
* What are the loan grades? (I had the text missing in the introduction)
* She explored the number of loans---the distribution.
* What DOES affect the prosperRating?

## Resources
http://stackoverflow.com/questions/31150764/how-to-create-a-new-column-of-data-in-r-with-if-statements

https://stackoverflow.com/questions/6104836/splitting-a-continuous-variable-into-equal-sized-groups

https://stackoverflow.com/questions/31869328/sort-a-list-alphabetically-with-characters-at-the-end
